from transformers import AutoTokenizer, AutoModelWithLMHead
import torch

# Load model and tokenizer
tokenizer = AutoTokenizer.from_pretrained("codeparrot/codeparrot-small")
model = AutoModelWithLMHead.from_pretrained("codeparrot/codeparrot-small")

# Your buggy code piece
buggy_code = """def bitcount(n):
    count = 0
    while n > 0:  
        n &= n + 1
        count += 1
    return count"""

# Create a more focused prompt
prompt = """# Original buggy code with n &= n + 1:
def bitcount(n):
    count = 0
    while n > 0:  
        n &= n + 1
        count += 1
    return count

# Fixed code with correct bitwise operation:
def bitcount(n):"""

# Tokenize input
inputs = tokenizer(prompt, return_tensors="pt")

# Generate with more constrained parameters
with torch.no_grad():
    outputs = model.generate(
        inputs.input_ids,
        max_length=1024,          # Shorter length to avoid repetition
        min_length=50,          # Ensure it generates enough to complete the function
        temperature=0.2,        # Low temperature for more focused output
        top_p=0.95,            
        no_repeat_ngram_size=3, # Prevent repetition of 3-grams
        num_beams=5,           # Use beam search
        early_stopping=True,    # Stop when complete
        pad_token_id=tokenizer.eos_token_id,
        eos_token_id=tokenizer.eos_token_id
    )

# Decode the output
generated_code = tokenizer.decode(outputs[0], skip_special_tokens=True)
print("Generated response:")
print(generated_code)