import os
import ast
from collections import defaultdict

def get_function_name(file_path):
    """Extract the main function name from a Python file"""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read().replace('\xa0', ' ')
            tree = ast.parse(content)
        
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                return node.name
    except Exception as e:
        print(f"Error reading {file_path}: {e}")
        return None

def rename_files(directory):
    """Rename files based on their function names"""
    # Keep track of implementations for each function
    implementation_count = defaultdict(int)
    rename_map = {}  # Store original to new name mapping
    
    # First pass - analyze all files and create new names
    for filename in sorted(os.listdir(directory)):
        if filename.endswith('.py') and filename.startswith('snippet_'):
            file_path = os.path.join(directory, filename)
            func_name = get_function_name(file_path)
            
            if func_name and func_name != '__init__':
                implementation_count[func_name] += 1
                new_name = f"{func_name}_{implementation_count[func_name]}.py"
                rename_map[filename] = new_name
    
    # Second pass - do the actual renaming
    print("\nRenaming files:")
    for old_name, new_name in rename_map.items():
        old_path = os.path.join(directory, old_name)
        new_path = os.path.join(directory, new_name)
        try:
            os.rename(old_path, new_path)
            print(f"{old_name} -> {new_name}")
        except Exception as e:
            print(f"Error renaming {old_name}: {e}")

    return implementation_count

if __name__ == "__main__":
    # Directory containing your code snippets
    directories = [
        'qwen_generated_codes'
    ]
    
    for directory in directories:
        print(f"\nProcessing {directory}:")
        implementation_count = rename_files(directory)
        
        print("\nSummary:")
        for func_name, count in sorted(implementation_count.items()):
            print(f"{func_name}: {count} implementation(s)")