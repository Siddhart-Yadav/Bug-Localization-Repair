import pandas as pd
import openai
import re
import os
# Set your OpenAI API key
openai.api_key = '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'


# Load the Excel file
file_path = 'TestData.xlsx'  # Update this path
data = pd.read_excel(file_path)

def extract_corrected_code(response):
    """
    Extracts the corrected code from the assistant's response.
    Looks for code blocks enclosed in triple backticks and extracts the code within.
    """
    # Use regular expression to find code blocks enclosed in triple backticks
    code_blocks = re.findall(r'```(?:python)?\n(.*?)```', response, re.DOTALL)

    if code_blocks:
        # Use the first code block found
        corrected_code = code_blocks[0]
    else:
        # If no code block is found, attempt to extract lines that look like code
        lines = response.strip().split('\n')
        code_lines = [
            line for line in lines
            if line.strip() and not line.strip().startswith('#') and not ':' in line[:10]
        ]
        corrected_code = '\n'.join(code_lines)

    return corrected_code.strip()

def query_model_for_correction(buggy_code, buggy_line):
    system_message = """You are a code fixing assistant. Your task is to identify and correct bugs in Python code.

When providing the corrected code:

- Output only the corrected code.
- Do not include any explanations or comments.
- Do not include any extra text outside the code.
- Preserve the original code formatting and structure as much as possible.

Example:
Buggy code:
def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i === 0:
            return False
    return True

Bug location: if num % i === 0:

Fixed code:
def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

Your task is to carefully analyze the given buggy code, identify the specific problematic line, and output only the corrected version of the code without any additional text."""

    user_message = f"""Buggy code:
{buggy_code}

Bug location: {buggy_line}

Please provide only the corrected version of this code."""

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4", 
            messages=[
                {"role": "system", "content": system_message},
                {"role": "user", "content": user_message}
            ],
            max_tokens=1024,
            temperature=0,
        )
        assistant_reply = response['choices'][0]['message']['content']
        return assistant_reply
    except Exception as e:
        print(f"OpenAI API error: {e}")
        return ""

# Create directories for code files
os.makedirs('gpt_4o_responses', exist_ok=True)

for idx, row in data.iterrows():
    print(f"Processing Snippet {idx + 1}...")

    buggy_code = row['Buggy Code']
    buggy_line = row['Buggy Line']

    if pd.isna(buggy_code) or pd.isna(buggy_line):
        print(f"Skipping Snippet {idx + 1} due to missing data.")
        continue

    response = query_model_for_correction(buggy_code, buggy_line)
    if not response:
        print(f"No response for Snippet {idx + 1}.")
        continue
    print(f"Raw Model Response for Snippet {idx + 1}:\n{response}\n{'-' * 50}")

    try:
        corrected_code = extract_corrected_code(response)
        if corrected_code:
            # Save code snippets to files
            generated_code_filename = f'gpt_4o_responses/snippet_{idx + 1}.py'
            with open(generated_code_filename, 'w', encoding='utf-8') as f:
                f.write(corrected_code)


            print(f"Corrected Code for Snippet {idx + 1} saved to {generated_code_filename}")
            print('-' * 50)
        else:
            print(f"No correction found for Snippet {idx + 1}.")
    except Exception as e:
        print(f"Error processing Snippet {idx + 1}: {str(e)}")