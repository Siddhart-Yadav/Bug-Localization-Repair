import os
import subprocess
from pathlib import Path
import json
from datetime import datetime

def run_all_tests():
   test_dir = Path('python_testcases')
   results = {}
   
   # Get all test files
   test_files = [f for f in test_dir.glob('test_*.py') if not f.name.startswith('__')]
   
   print(f"Found {len(test_files)} test files to run")
   
   for test_file in test_files:
       func_name = test_file.stem.replace('test_', '')
       print(f"\nRunning tests for {func_name}...")
       
       # Run pytest with timeout
       try:
           command = f"PYTHONPATH=. pytest {test_file} -v"
           result = subprocess.run(
               command,
               shell=True,
               capture_output=True,
               text=True,
               env={**os.environ, 'PYTHONPATH': '.'},
               timeout=30  # 30 seconds timeout
           )
           
           results[func_name] = {
               'passed': result.returncode == 0,
               'output': result.stdout,
               'error': result.stderr if result.returncode != 0 else None,
               'timeout': False
           }
           
           # Print immediate results
           print(f"{result.stdout}")
           
       except subprocess.TimeoutExpired:
           print(f"Timeout occurred for {func_name}")
           results[func_name] = {
               'passed': False,
               'output': "Test timed out after 30 seconds",
               'error': "Timeout Error: Test took too long to complete",
               'timeout': True
           }

   # Generate report
   report = {
       'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
       'summary': {
           'total_programs': len(results),
           'passed': sum(1 for r in results.values() if r['passed']),
           'failed': sum(1 for r in results.values() if not r['passed'])
       },
       'detailed_results': results
   }
   
   # Save JSON report
   with open('test_report.json', 'w') as f:
       json.dump(report, f, indent=2)
       
   # Generate text report
   with open('test_report.txt', 'w') as f:
       f.write(f"Test Report ({report['timestamp']})\n")
       f.write("=" * 80 + "\n\n")
       
       # Overall Summary
       f.write("Overall Summary:\n")
       f.write("-" * 80 + "\n")
       f.write(f"Total Programs Tested: {report['summary']['total_programs']}\n")
       f.write(f"Total Programs Passed: {report['summary']['passed']}\n")
       f.write(f"Total Programs Failed: {report['summary']['failed']}\n\n")
       
       # Detailed Results Table
       f.write("Detailed Results By Implementation:\n")
       f.write("-" * 80 + "\n")
       f.write(f"{'Program':<30} {'Total Tests':<15} {'Passed':<15} {'Failed':<15}\n")
       f.write("-" * 80 + "\n")
       
       for program, result in sorted(results.items()):
           # Handle timeout cases differently
           if result.get('timeout', False):
               total_tests = 1
               passed_tests = 0
               failed_tests = 1
               f.write(f"{program:<30} {total_tests:<15} {passed_tests:<15} {'TIMEOUT':<15}\n")
           else:
               # Parse test output for PASSED and FAILED counts
               test_output = result['output'].split('\n')
               total_tests = 0
               passed_tests = 0
               failed_tests = 0
               
               for line in test_output:
                   if 'PASSED' in line:
                       total_tests += 1
                       passed_tests += 1
                   elif 'FAILED' in line or 'ERROR' in line:
                       total_tests += 1
                       failed_tests += 1
               
               f.write(f"{program:<30} {total_tests:<15} {passed_tests:<15} {failed_tests:<15}\n")
       
       f.write("-" * 80 + "\n\n")
       
       # Summary at Bottom
       f.write("\nTest Execution Summary:\n")
       f.write("-" * 80 + "\n")
       f.write(f"Total Programs: {report['summary']['total_programs']}\n")
       f.write(f"Passed: {report['summary']['passed']}\n")
       f.write(f"Failed: {report['summary']['failed']}\n\n")
       
       # Detailed Test Output Section
       f.write("\nDetailed Test Output:\n")
       f.write("=" * 80 + "\n\n")
       
       for program, result in sorted(results.items()):
           f.write(f"\n{program}:\n")
           f.write("-" * 80 + "\n")
           if result.get('timeout', False):
               f.write("Test output: TIMEOUT\n")
               f.write("Test timed out after 30 seconds\n")
           else:
               f.write("Test output:\n")
               f.write(result['output'])
               if not result['passed'] and result['error']:
                   f.write("\nError output:\n")
                   f.write(result['error'])
           f.write("\n")
   
   # Print summary to console
   print("\n" + "=" * 50)
   print("Test Execution Complete")
   print(f"Total Programs: {report['summary']['total_programs']}")
   print(f"Passed: {report['summary']['passed']}")
   print(f"Failed: {report['summary']['failed']}")
   print("\nDetailed reports saved to:")
   print("- test_report.json")
   print("- test_report.txt")

if __name__ == "__main__":
   run_all_tests()