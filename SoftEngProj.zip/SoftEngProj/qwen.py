import pandas as pd
import requests
import re
import os

# Set your Hugging Face API token
HF_API_TOKEN = "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"

# Load the Excel file
file_path = 'TestData.xlsx'
data = pd.read_excel(file_path)

def extract_corrected_code(response):
    """
    Extracts only the corrected code from the model's response,
    ignoring the prompt and example portions.
    """
    # First try to find code blocks with triple backticks
    code_blocks = re.findall(r'```(?:python)?\n(.*?)```', response, re.DOTALL)
    
    if code_blocks:
        # Use the last code block found (usually the corrected version)
        return code_blocks[-1].strip()
    
    # If no code blocks, look for the code after "Return only the complete corrected code"
    marker = "Return only the complete corrected code without any explanations."
    if marker in response:
        parts = response.split(marker)
        if len(parts) > 1:
            # Take the code after the marker, before any potential following text
            code = parts[1].strip()
            # If there's a "Code:" prefix, remove it
            if code.startswith("Code:"):
                code = code.replace("Code:", "", 1).strip()
            return code
    
    # If still no luck, look for the code after "Fixed code:" or just try to get
    # the last def/class block in the response
    if "Fixed code:" in response:
        parts = response.split("Fixed code:")
        if len(parts) > 1:
            code = parts[1].strip()
            # Remove any trailing text after the code block
            code_lines = []
            for line in code.split('\n'):
                if line.strip() and not line.startswith(('Your task', 'Return only', 'Bug location:')):
                    code_lines.append(line)
                elif code_lines:  # If we've already started collecting code and hit a non-code line
                    break
            return '\n'.join(code_lines).strip()
    
    # Last resort: try to find the last code block that starts with 'def' or 'class'
    lines = response.split('\n')
    code_block = []
    in_code_block = False
    
    for line in lines:
        if line.strip().startswith(('def ', 'class ')):
            code_block = [line]
            in_code_block = True
        elif in_code_block:
            if not line.strip() and not any(l.strip() for l in lines[lines.index(line)+1:]):
                break
            code_block.append(line)
    
    if code_block:
        return '\n'.join(code_block).strip()
    
    return ""

def query_model_for_correction(buggy_code, buggy_line):
    API_URL = "https://api-inference.huggingface.co/models/Qwen/Qwen2.5-Coder-32B-Instruct"
    headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}

    # More direct prompt
    prompt = f"""You are a code fixing assistant. Your task is to identify and correct bugs in Python code.

When providing the corrected code:

- Output only the corrected code.
- Do not include any explanations or comments.
- Do not include any extra text outside the code.
- Preserve the original code formatting and structure as much as possible.

Example:
Buggy code:
def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i === 0:
            return False
    return True

Bug location: if num % i === 0:

Fixed code:
def is_prime(num):
    if num <= 1:
        return False
    for i in range(2, int(num ** 0.5) + 1):
        if num % i == 0:
            return False
    return True

Your task is to carefully analyze the given buggy code, identify the specific problematic line, and output only the corrected version of the code without any additional text.
 The bug is in line {buggy_line}.
Code:
{buggy_code}

Return only the complete corrected code without any explanations."""

    try:
        response = requests.post(
            API_URL,
            headers=headers,
            json={
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 1024,
                    "temperature": 0.1,  # Lower temperature for more focused output
                    "top_p": 0.9,
                    "stop": ["</code>", "Here is", "The corrected"]  # Stop sequences to prevent extra text
                }
            }
        )
        
        # Rest of the function remains the same...
        
        if response.status_code == 200:
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                return result[0].get('generated_text', '')
            return result.get('generated_text', '')
        else:
            print(f"API Error: Status Code {response.status_code}")
            print(f"Response content: {response.text}")  # Add this line to see detailed error message
            
            # Add retry with simplified parameters if initial request fails
            try:
                simplified_response = requests.post(
                    API_URL,
                    headers=headers,
                    json={
                        "inputs": prompt,
                        "parameters": {
                            "max_new_tokens": 512,
                            "temperature": 0.7
                        }
                    }
                )
                if simplified_response.status_code == 200:
                    result = simplified_response.json()
                    if isinstance(result, list) and len(result) > 0:
                        return result[0].get('generated_text', '')
                    return result.get('generated_text', '')
            except Exception as retry_error:
                print(f"Retry attempt failed: {retry_error}")
            
            return ""
            
    except Exception as e:
        print(f"Hugging Face API error: {e}")
        return ""
# Create directories for code files
os.makedirs('qwen_generated_codes', exist_ok=True)

# Process each row in the Excel file
for idx, row in data.iterrows():
    print(f"Processing Snippet {idx + 1}...")

    buggy_code = row['Buggy Code']
    buggy_line = row['Buggy Line']

    if pd.isna(buggy_code) or pd.isna(buggy_line):
        print(f"Skipping Snippet {idx + 1} due to missing data.")
        continue

    response = query_model_for_correction(buggy_code, buggy_line)
    if not response:
        print(f"No response for Snippet {idx + 1}.")
        continue
    print(f"Raw Model Response for Snippet {idx + 1}:\n{response}\n{'-' * 50}")

    try:
        corrected_code = extract_corrected_code(response)
        if corrected_code:
            # Save code snippets to files
            generated_code_filename = f'qwen_generated_codes/snippet_{idx + 1}.py'
            with open(generated_code_filename, 'w', encoding='utf-8') as f:
                f.write(corrected_code)

            print(f"Corrected Code for Snippet {idx + 1} saved to {generated_code_filename}")
            print('-' * 50)
        else:
            print(f"No correction found for Snippet {idx + 1}.")
    except Exception as e:
        print(f"Error processing Snippet {idx + 1}: {str(e)}")