import os
from pathlib import Path

def has_json_testcases(file_content):
    """Check if the test file uses json test cases"""
    return 'load_json_testcases' in file_content or 'load_testdata' in file_content

def create_new_test_content_with_json(function_name):
    """Create content for tests that use JSON test cases"""
    return f'''import pytest
from load_testdata import load_json_testcases
import importlib
import glob
import os

# Find all implementations
implementations = glob.glob('implementations/qwen_generated_codes/{function_name}_*.py')
implementation_ids = [os.path.basename(imp).replace('.py','') for imp in implementations]

# Get current implementation being tested
def get_implementation():
    implementation_name = os.getenv('IMPLEMENTATION', '{function_name}_1')
    module_path = f'implementations.qwen_generated_codes.{{implementation_name}}'
    module = importlib.import_module(module_path)
    return module.{function_name}

testdata = load_json_testcases('{function_name}')

@pytest.mark.parametrize("implementation", implementation_ids)
@pytest.mark.parametrize("input_data,expected", testdata)
def test_{function_name}(input_data, expected, implementation, monkeypatch):
    os.environ['IMPLEMENTATION'] = implementation
    {function_name} = get_implementation()
    assert {function_name}(*input_data) == expected
'''

def create_new_test_content_without_json(original_content, function_name):
    """Modify test content that doesn't use JSON test cases"""
    lines = original_content.split('\n')
    new_lines = []
    import_section = []
    test_section = []
    
    # Skip the conditional import section and keep other imports
    in_import = True
    skip_next = False
    for line in lines:
        if line.startswith('def test'):
            in_import = False
        if in_import:
            # Skip if/else and their associated import lines
            if 'if pytest.use_correct:' in line:
                skip_next = True
                continue
            elif line.strip().startswith('else:'):
                skip_next = True
                continue
            elif skip_next:
                skip_next = False
                continue
            # Keep all other imports
            if not any(x in line for x in ['from correct_python_programs', 'from python_programs']):
                import_section.append(line)
        else:
            test_section.append(line)
    
    # Add our new imports and implementation loading
    new_lines.extend(import_section)
    new_lines.extend([
        '',
        'import importlib',
        'import glob',
        'import os',
        '',
        f'# Find all implementations',
        f'implementations = glob.glob("implementations/qwen_generated_codes/{function_name}_*.py")',
        f'implementation_ids = [os.path.basename(imp).replace(".py","") for imp in implementations]',
        '',
        f'def get_implementation():',
        f'    implementation_name = os.getenv("IMPLEMENTATION", "{function_name}_1")',
        f'    module_path = f"implementations.qwen_generated_codes.{{implementation_name}}"',
        f'    module = importlib.import_module(module_path)',
        f'    return module.{function_name}',
        ''
    ])
    
    # Add parameterization to each test function
    modified_test_section = []
    for line in test_section:
        if line.startswith('def test'):
            modified_test_section.append('@pytest.mark.parametrize("implementation", implementation_ids)')
            # Modify test function to accept implementation parameter
            line = line.replace('():', '(implementation):')
            modified_test_section.append(line)
            modified_test_section.append(f'    os.environ["IMPLEMENTATION"] = implementation')
            modified_test_section.append(f'    {function_name} = get_implementation()')
        else:
            modified_test_section.append(line)
    
    new_lines.extend(modified_test_section)
    return '\n'.join(new_lines)

def modify_test_files():
    test_dir = Path('python_testcases')
    test_files = test_dir.glob('test_*.py')
    
    for test_file in test_files:
        if test_file.name.startswith('__'):
            continue
            
        function_name = test_file.stem.replace('test_', '')
        print(f"Processing {test_file.name}...")
        
        # Read original content
        with open(test_file, 'r') as f:
            original_content = f.read()
        
        # Create backup
        backup_file = test_file.with_suffix('.py.bak')
        if not backup_file.exists():
            test_file.rename(backup_file)
        
        # Create appropriate new content
        if has_json_testcases(original_content):
            new_content = create_new_test_content_with_json(function_name)
        else:
            new_content = create_new_test_content_without_json(original_content, function_name)
        
        # Write new content
        with open(test_file, 'w') as f:
            f.write(new_content)
            
        print(f"Updated {test_file.name}")

if __name__ == "__main__":
    modify_test_files()