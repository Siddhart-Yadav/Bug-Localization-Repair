import pandas as pd
import requests
import re
import os

# Set your Hugging Face API token
HF_API_TOKEN = "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"

def extract_buggy_line(response):
    """
    Extracts the buggy line from the response after 'Buggy Line:' marker
    """
    match = re.search(r'Buggy Line:(.*)', response, re.DOTALL)
    if match:
        return match.group(1).strip()
    
    # Fallback: try to find any line that's clearly marked as buggy
    lines = response.split('\n')
    for line in lines:
        if line.strip().startswith('Buggy Line:'):
            return line.replace('Buggy Line:', '').strip()
    return ""

def query_model_for_bug_identification(snippet):
    API_URL = "https://api-inference.huggingface.co/models/Qwen/Qwen2.5-Coder-32B-Instruct"
    headers = {"Authorization": f"Bearer {HF_API_TOKEN}"}

    prompt = f"""You are an Analyst who always extracts one buggy line in the provided Python code.
Please analyze the following code and locate the buggy line. Only output the buggy line and nothing else under the text 'Buggy Line:':

```python
{snippet}
```"""

    try:
        response = requests.post(
            API_URL,
            headers=headers,
            json={
                "inputs": prompt,
                "parameters": {
                    "max_new_tokens": 512,
                    "temperature": 0.1,
                    "top_p": 0.9,
                    "stop": ["```", "Here is", "The bug"]
                }
            }
        )
        
        if response.status_code == 200:
            result = response.json()
            if isinstance(result, list) and len(result) > 0:
                return extract_buggy_line(result[0].get('generated_text', ''))
            return extract_buggy_line(result.get('generated_text', ''))
        else:
            print(f"API Error: Status Code {response.status_code}")
            print(f"Response content: {response.text}")
            
            # Retry with simplified parameters if initial request fails
            try:
                simplified_response = requests.post(
                    API_URL,
                    headers=headers,
                    json={
                        "inputs": prompt,
                        "parameters": {
                            "max_new_tokens": 256,
                            "temperature": 0.7
                        }
                    }
                )
                if simplified_response.status_code == 200:
                    result = simplified_response.json()
                    if isinstance(result, list) and len(result) > 0:
                        return extract_buggy_line(result[0].get('generated_text', ''))
                    return extract_buggy_line(result.get('generated_text', ''))
            except Exception as retry_error:
                print(f"Retry attempt failed: {retry_error}")
            
            return ""
            
    except Exception as e:
        print(f"Hugging Face API error: {e}")
        return ""

# Load the Excel file
file_path = 'TestData.xlsx'
data = pd.read_excel(file_path)

# Create a new column for identified buggy lines
data['Identified_Buggy_Line'] = None

# Create directory for responses
os.makedirs('qwen_bug_identification', exist_ok=True)

# Process each code snippet
for idx, row in data.iterrows():
    print(f"Processing Snippet {idx + 1}...")
    
    buggy_code = row['Buggy Code']
    
    if pd.isna(buggy_code):
        print(f"Skipping Snippet {idx + 1} due to missing code.")
        continue
    
    # Get the identified buggy line
    identified_buggy_line = query_model_for_bug_identification(buggy_code)
    
    # Save the response
    response_filename = f'qwen_bug_identification/snippet_{idx + 1}_analysis.txt'
    with open(response_filename, 'w', encoding='utf-8') as f:
        f.write(f"Original Code:\n{buggy_code}\n\nIdentified Buggy Line:\n{identified_buggy_line}")
    
    # Update the DataFrame
    data.at[idx, 'Identified_Buggy_Line'] = identified_buggy_line
    
    print(f"Processed Snippet {idx + 1}")
    print(f"Identified Buggy Line: {identified_buggy_line}")
    print('-' * 50)

# Save the updated DataFrame to a new Excel file
output_file = 'TestData_with_qwen_identified_bugs.xlsx'
data.to_excel(output_file, index=False)
print(f"Results saved to {output_file}")