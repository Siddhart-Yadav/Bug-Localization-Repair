import ast
import os
import difflib

def normalize_code(code_str):
    """
    Normalize code by:
    1. Parsing it into an AST
    2. Removing comments and docstrings
    3. Normalizing whitespace
    """
    try:
        # Parse the code into an AST
        tree = ast.parse(code_str)
        
        # Remove all docstrings and comments
        for node in ast.walk(tree):
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Str):
                node.value.s = ""
            
        # Convert back to code
        normalized = ast.unparse(tree)
        
        # Normalize whitespace
        normalized = ' '.join(normalized.split())
        return normalized
    except Exception as e:
        print(f"Error normalizing code: {e}")
        return code_str

def compare_code_files(file1_path, file2_path):
    """
    Compare two Python code files for semantic equality.
    Returns a tuple of (is_equal, similarity_score, differences)
    """
    try:
        # Read both files
        with open(file1_path, 'r') as f1, open(file2_path, 'r') as f2:
            code1 = f1.read()
            code2 = f2.read()
        
        # Normalize both code snippets
        norm_code1 = normalize_code(code1)
        norm_code2 = normalize_code(code2)
        
        # Calculate similarity using difflib
        similarity = difflib.SequenceMatcher(None, norm_code1, norm_code2).ratio()
        
        # Get differences if any
        differ = difflib.Differ()
        diff = list(differ.compare(code1.splitlines(), code2.splitlines()))
        
        # Filter meaningful differences
        meaningful_diff = [d for d in diff if d.startswith(('+ ', '- ', '? '))]
        
        # Consider codes equal if similarity is above 0.95
        is_equal = similarity >= 0.95
        
        return is_equal, similarity, meaningful_diff
    except Exception as e:
        print(f"Error comparing files: {e}")
        return False, 0.0, []

def compare_models(base_dir, fine_tuned_dir, ground_truth_dir):
    """
    Compare performance of base and fine-tuned models against ground truth
    """
    def evaluate_model(model_dir):
        results = []
        files1 = sorted([f for f in os.listdir(model_dir) if f.endswith('.py')])
        files2 = sorted([f for f in os.listdir(ground_truth_dir) if f.endswith('.py')])
        
        for file1 in files1:
            if file1 in files2:
                file1_path = os.path.join(model_dir, file1)
                file2_path = os.path.join(ground_truth_dir, file1)
                
                is_equal, similarity, _ = compare_code_files(file1_path, file2_path)
                results.append({
                    'file': file1,
                    'is_equal': is_equal,
                    'similarity': similarity
                })
        
        total_files = len(results)
        equal_files = sum(1 for r in results if r['is_equal'])
        exact_match_accuracy = round(equal_files / total_files, 3)
        
        return {
            'total_files': total_files,
            'equal_files': equal_files,
            'exact_match_accuracy': exact_match_accuracy,
            'detailed_results': results
        }
    
    # Evaluate both models
    print("Evaluating Base Model...")
    base_metrics = evaluate_model(base_dir)
    
    print("Evaluating Fine-tuned Model...")
    fine_tuned_metrics = evaluate_model(fine_tuned_dir)
    
    # Print comparison table
    print("\nModel Performance Comparison")
    print("-" * 50)
    print("Model          | Exact Match")
    print("-" * 50)
    print(f"Base Model     | {base_metrics['exact_match_accuracy']:.3f}")
    print(f"Fine-tuned     | {fine_tuned_metrics['exact_match_accuracy']:.3f}")
    
    return {
        'base_model': base_metrics,
        'fine_tuned_model': fine_tuned_metrics
    }

def generate_detailed_report(metrics, output_file="comparison_report.txt"):
    """
    Generate a detailed report of the comparison
    """
    with open(output_file, 'w') as f:
        f.write("Model Performance Report\n")
        f.write("=" * 50 + "\n\n")
        
        # Base Model Details
        f.write("Base Model:\n")
        f.write("-" * 20 + "\n")
        f.write(f"Total files compared: {metrics['base_model']['total_files']}\n")
        f.write(f"Exact matches: {metrics['base_model']['equal_files']}\n")
        f.write(f"Exact match accuracy: {metrics['base_model']['exact_match_accuracy']:.3f}\n\n")
        
        # Fine-tuned Model Details
        f.write("Fine-tuned Model:\n")
        f.write("-" * 20 + "\n")
        f.write(f"Total files compared: {metrics['fine_tuned_model']['total_files']}\n")
        f.write(f"Exact matches: {metrics['fine_tuned_model']['equal_files']}\n")
        f.write(f"Exact match accuracy: {metrics['fine_tuned_model']['exact_match_accuracy']:.3f}\n")

# Example usage
ground_truth_dir = 'implementations/SixtyFive_correct_code_snippets'
base_model_dir = 'implementations/untrained_code_snippets'
fine_tuned_dir = 'implementations/qwen_generated_codes'

# Run comparison
metrics = compare_models(base_model_dir, fine_tuned_dir, ground_truth_dir)

# Generate detailed report
generate_detailed_report(metrics)

print("\nDetailed report has been generated in 'comparison_report.txt'")

# Example usage
# qwen_dir = 'implementations/SixtyFive_model_code_snippets'
# ground_truth_dir = 'implementations/SixtyFive_correct_code_snippets'

# results = compare_code_directories(qwen_dir, ground_truth_dir)