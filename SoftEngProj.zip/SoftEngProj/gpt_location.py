import pandas as pd
import openai
import re
import os

# Set your OpenAI API key
openai.api_key = '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'

def extract_buggy_line(response):
    """
    Extracts the buggy line from the response after 'Buggy Line:' marker
    """
    match = re.search(r'Buggy Line:(.*)', response, re.DOTALL)
    if match:
        return match.group(1).strip()
    return ""

def query_model_for_bug_identification(snippet):
    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are an Analyst who always extracts one buggy line in the provided Python code."},
                {"role": "user", "content": f"Please analyze the following code and locate the buggy line. Only output the buggy line and nothing else under the text 'Buggy Line:':\n\n```python\n{snippet}\n```"}
            ],
            max_tokens=1024,
            temperature=0,
        )
        full_response = response['choices'][0]['message']['content']
        return extract_buggy_line(full_response)
    except Exception as e:
        print(f"OpenAI API error: {e}")
        return ""

# Load the Excel file with buggy code
file_path = 'TestData.xlsx'  # Update this path
data = pd.read_excel(file_path)

# Create a new column for identified buggy lines
data['Identified_Buggy_Line'] = None

# Create directory for responses
os.makedirs('bug_identification_responses', exist_ok=True)

# Process each code snippet
for idx, row in data.iterrows():
    print(f"Processing Snippet {idx + 1}...")
    
    buggy_code = row['Buggy Code']
    
    if pd.isna(buggy_code):
        print(f"Skipping Snippet {idx + 1} due to missing code.")
        continue
    
    # Get the identified buggy line
    identified_buggy_line = query_model_for_bug_identification(buggy_code)
    
    # Save the response
    response_filename = f'bug_identification_responses/snippet_{idx + 1}_analysis.txt'
    with open(response_filename, 'w', encoding='utf-8') as f:
        f.write(f"Original Code:\n{buggy_code}\n\nIdentified Buggy Line:\n{identified_buggy_line}")
    
    # Update the DataFrame
    data.at[idx, 'Identified_Buggy_Line'] = identified_buggy_line
    
    print(f"Processed Snippet {idx + 1}")
    print(f"Identified Buggy Line: {identified_buggy_line}")
    print('-' * 50)

# Save the updated DataFrame to a new Excel file
output_file = 'TestData_with_identified_bugs.xlsx'
data.to_excel(output_file, index=False)
print(f"Results saved to {output_file}")