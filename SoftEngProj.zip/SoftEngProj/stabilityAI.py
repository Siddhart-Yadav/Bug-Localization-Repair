import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import re
import os
import time

# Load the model and tokenizer
tokenizer = AutoTokenizer.from_pretrained("stabilityai/stable-code-instruct-3b", trust_remote_code=True)
model = AutoModelForCausalLM.from_pretrained("stabilityai/stable-code-instruct-3b", torch_dtype=torch.float32, trust_remote_code=True)
model.eval()

# Load the Excel file
file_path = 'check.xlsx'
data = pd.read_excel(file_path)

def extract_corrected_code(response):
    """
    Extracts the corrected code from the model's response.
    """
    code_blocks = re.findall(r'```(?:python)?\n(.*?)```', response, re.DOTALL)

    if code_blocks:
        corrected_code = code_blocks[0]
    else:
        lines = response.strip().split('\n')
        code_lines = [
            line for line in lines
            if line.strip() and not line.strip().startswith('#') and not ':' in line[:10]
        ]
        corrected_code = '\n'.join(code_lines)

    return corrected_code.strip()

def query_model_for_correction(buggy_code, buggy_line):
    system_message = """You are a code fixing assistant. Your task is to identify and correct bugs in Python code.
    When providing the corrected code:
    - Output only the corrected code.
    - Do not include any explanations or comments.
    - Do not include any extra text outside the code.
    - Preserve the original code formatting and structure as much as possible."""

    user_message = f"""Buggy code:
    {buggy_code}

    Bug location: {buggy_line}

    Please provide only the corrected version of this code."""

    messages = [
        {"role": "system", "content": system_message},
        {"role": "user", "content": user_message}
    ]

    prompt = tokenizer.apply_chat_template(messages, add_generation_prompt=True, tokenize=False)
    
    input_ids = tokenizer(prompt, return_tensors="pt").input_ids
    attention_mask = tokenizer(prompt, return_tensors="pt").attention_mask
    output = model.generate(
        input_ids,
        attention_mask=attention_mask,
        do_sample=True,
        temperature=0.1,
        max_length=1000
    )
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    
    return response

# Create directories for code files
os.makedirs('stable_code_instruct_generated_codes', exist_ok=True)
os.makedirs('ground_truth_codes', exist_ok=True)

# Process each row in the Excel file
for idx, row in data.iterrows():
    print(f"\nProcessing Snippet {idx + 1}...")

    buggy_code = row['Buggy Code']
    buggy_line = row['Buggy Line']

    if pd.isna(buggy_code) or pd.isna(buggy_line):
        print(f"Skipping Snippet {idx + 1} due to missing data.")
        continue

    response = query_model_for_correction(buggy_code, buggy_line)
    
    # Add delay between requests to prevent overload
    time.sleep(3)
    
    if not response:
        print(f"No response for Snippet {idx + 1}.")
        continue
    print(f"Raw Model Response for Snippet {idx + 1}:\n{response}\n{'-' * 50}")

    try:
        corrected_code = extract_corrected_code(response)
        if corrected_code:
            # Save code snippets to files
            generated_code_filename = f'stable_code_instruct_generated_codes/snippet_{idx + 1}.py'
            with open(generated_code_filename, 'w', encoding='utf-8') as f:
                f.write(corrected_code)

            ground_truth_filename = f'ground_truth_codes/snippet_{idx + 1}.py'
            with open(ground_truth_filename, 'w', encoding='utf-8') as f:
                f.write(row.get('Correct Code', ''))

            print(f"Corrected Code for Snippet {idx + 1} saved to {generated_code_filename}")
            print(f"Original Correct Code for Snippet {idx + 1} saved to {ground_truth_filename}")
            print('-' * 50)
        else:
            print(f"No correction found for Snippet {idx + 1}.")
    except Exception as e:
        print(f"Error processing Snippet {idx + 1}: {str(e)}")