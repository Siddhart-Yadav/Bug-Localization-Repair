import pandas as pd

def calculate_bug_localization_accuracy(csv_file):
    """
    Calculate Top-1 and Top-3 accuracy from CSV data
    """
    try:
        df = pd.read_csv(csv_file)
        total_samples = len(df)
        top1_correct = 0
        top3_correct = 0
        
        for index, row in df.iterrows():
            try:
                predicted_line = str(row['buggy_line']).strip()
                actual_line = str(row['buggy_line_actual']).strip()
                code = str(row['actual_code']).strip()
                
                # Split code into lines and strip whitespace
                code_lines = [line.strip() for line in code.split('\n') if line.strip()]
                
                # Find position of actual buggy line in code
                actual_pos = -1
                for i, line in enumerate(code_lines):
                    if actual_line in line:
                        actual_pos = i
                        break
                
                # Find position of predicted buggy line in code
                predicted_pos = -1
                for i, line in enumerate(code_lines):
                    if predicted_line in line:
                        predicted_pos = i
                        break
                
                # Top-1: Exact position match
                if predicted_pos == actual_pos and predicted_pos != -1:
                    top1_correct += 1
                    top3_correct += 1
                # Top-3: Within ±1 line of actual position
                elif predicted_pos != -1 and actual_pos != -1:
                    if abs(predicted_pos - actual_pos) <= 1:
                        top3_correct += 1
                        
            except Exception as e:
                print(f"Error processing row {index}: {e}")
                continue
        
        # Calculate accuracies in decimal format
        top1_accuracy = round(top1_correct / total_samples, 3)
        top3_accuracy = round(top3_correct / total_samples, 3)
        
        print("\nBug Localization Performance")
        print("-" * 50)
        print(f"Total samples analyzed: {total_samples}")
        print(f"Exact matches (Top-1): {top1_correct}")
        print(f"Within ±1 line (Top-3): {top3_correct}")
        print("\nAccuracy Metrics (Paper Format)")
        print("-" * 50)
        print(f"Top-1 Accuracy: {top1_accuracy}")
        print(f"Top-3 Accuracy: {top3_accuracy}")
        
        return {
            'top1': top1_accuracy,
            'top3': top3_accuracy,
            'samples': total_samples,
            'top1_matches': top1_correct,
            'top3_matches': top3_correct
        }
        
    except Exception as e:
        print(f"Error processing file: {e}")
        return None

if __name__ == "__main__":
    csv_file = "BugLocateTrainResponses.csv"
    metrics = calculate_bug_localization_accuracy(csv_file)