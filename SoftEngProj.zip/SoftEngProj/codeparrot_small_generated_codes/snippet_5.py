def check_bitcount(code):
corrected_count = bitcounts(code)
if code == corrected_code:
return corrected_bitcounts
else:
raise ValueError("corrected code must be %s, got %s" % (str(corrected_count), str(code)))
if __name__ == "__main__":
print(bitcount("abc"))
count(2)
print_version()