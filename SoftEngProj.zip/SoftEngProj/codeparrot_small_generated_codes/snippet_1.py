bitcount(1)
def main():
parser = argparse.ArgumentParser(description='Calculate the number of bits in a set of registers.')
parser.add_argument('set', nargs='+', type=int, help='Set number of registers to calculate.')
args = parser.parse_args()
main_set = args.set[0]
print(main_set)
main()
if __name__ == '__main__':
sys.exit(main())