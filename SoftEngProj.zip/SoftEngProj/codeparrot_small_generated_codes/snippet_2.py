bitcount(1)
if __name__ == '__main__':
main()
sys.path.insert(0, os.getcwd())
try:
sys.modules.pop('h5py')
except KeyError:
bitcount = bitcount_corrected(sys.modules[__name__])
os.chdir(os.getcwd() + '/..')
with open('tests/' + __file + 'bitcount.py', 'w') as f:
f.write('import sys\n' + 'sys.stdout.encoding = sys.stderr.encoding\n