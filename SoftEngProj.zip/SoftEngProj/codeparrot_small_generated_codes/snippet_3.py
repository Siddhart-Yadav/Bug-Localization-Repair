bitcount(0)
print bitcount('1')
print count(bitcount('2'))
def _get_object_name(client, context):
"""
Get the object name by checking if it is a valid object name.
:param client: Client to fetch object name from
:param context:
:return: Object name
:rtype: str
"""
try:
_