class TestBitcount(unittest.TestCase):
def setUp(self):
self.module = AnsibleModule(
argument_spec=nexus_argument.NexusModuleSpec(),
supports_check_mode=True,
mutually_exclusive=dict(type='list'),
)
args = re.split(os.path.sep, str(self.module.params['lines']))
for arg in args:
if re.match('^[0-9a-fA-F]{1,8}.*$', arg):
self.bitcount_argument = arg
else:
bitcount_version = bitcount