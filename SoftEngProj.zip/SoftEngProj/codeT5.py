from transformers import T5ForConditionalGeneration, AutoTokenizer

def fix_buggy_code(buggy_code, example_fix=None):
    """
    Use CodeT5+ to fix buggy code with optional example.
    
    Args:
        buggy_code (str): The buggy code to fix
        example_fix (tuple): Optional tuple of (buggy, fixed) code example
    
    Returns:
        str: The model's suggested fix
    """
    checkpoint = "Salesforce/codet5p-220m"
    device = "cpu"

    tokenizer = AutoTokenizer.from_pretrained(checkpoint)
    model = T5ForConditionalGeneration.from_pretrained(checkpoint).to(device)

    # Construct prompt
    if example_fix:
        buggy_example, fixed_example = example_fix
        prompt = f"""
Fix bug in:
{buggy_example}
Fixed:
{fixed_example}

Fix bug in:
{buggy_code}
Fixed:"""
    else:
        prompt = f"Fix bug in:\n{buggy_code}\nFixed:"

    # Encode and generate
    inputs = tokenizer.encode(prompt, return_tensors="pt").to(device)
    outputs = model.generate(
        inputs,
        max_length=256,
        temperature=0.2,
        do_sample=True,
        num_return_sequences=1
    )
    
    return tokenizer.decode(outputs[0], skip_special_tokens=True)

# Example usage
buggy_code = """
def calculate_average(numbers):
    total = 0
    for num in numbers:
        total += num
    return total  # Bug: forgetting to divide by length
"""

example_bug = """
def find_max(lst):
    max_val = lst[0]
    for x in lst:
        if x > max_val:
            max_val = x
    return  # Bug: missing return value
"""

example_fix = """
def find_max(lst):
    max_val = lst[0]
    for x in lst:
        if x > max_val:
            max_val = x
    return max_val
"""

# Fix with example
fixed_code = fix_buggy_code(buggy_code, (example_bug, example_fix))
print("Fixed code with example:")
print(fixed_code)

# Fix without example
fixed_code_no_example = fix_buggy_code(buggy_code)
print("\nFixed code without example:")
print(fixed_code_no_example)