def depth_first_search(startnode, goalnode):
    nodesvisited = set()
    def search_from(node):
        if node is goalnode:
            return True
        elif node not in nodesvisited:
            nodesvisited.add(node)
            return any(
                search_from(nextnode) for nextnode in node.successors
            )
        else:
            return False
    return search_from(startnode)