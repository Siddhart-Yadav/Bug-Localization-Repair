class Node:
    def __init__(self, value=None, successor=None, successors=None, predecessors=None, incoming_nodes=None, outgoing_nodes=None):
        self.value = value
        self._successor = successor
        self._successors = successors
        self._predecessors = predecessors
        self.incoming_nodes = incoming_nodes
        self.outgoing_nodes = outgoing_nodes
    def successor(self):
        return self._successor
    def successors(self):
        return self._successors
    def predecessors(self):
        return self._predecessors