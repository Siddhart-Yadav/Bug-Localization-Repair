class Node:
    def __init__(self, value=None, successor=None, successors=None, predecessors=None, incoming_nodes=None, outgoing_nodes=None):
        if successors is None:
            successors = []
        if predecessors is None:
            predecessors = []
        if incoming_nodes is None:
            incoming_nodes = []
        if outgoing_nodes is None:
            outgoing_nodes = []
        self.value = value
        self.successor = successor
        self.successors = successors
        self.predecessors = predecessors
        self.incoming_nodes = incoming_nodes
        self.outgoing_nodes = outgoing_nodes
    def successor(self):
        return self.successor
    def successors(self):
        return self.successors
    def predecessors(self):
        return self.predecessors