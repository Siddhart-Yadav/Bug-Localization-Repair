def shortest_paths(source, weight_by_edge):
    weight_by_node = {
    }
    weight_by_node[source] = 0
    for i in range(len(weight_by_node) - 1):
        for (u, v), weight in weight_by_edge.items():
            weight_by_node[v] = min(
                weight_by_node.get(u, float('inf')) + weight,
                weight_by_node.get(v, float('inf'))
            )
    return {k: v if v != float('inf') else None for k, v in weight_by_node.items()}