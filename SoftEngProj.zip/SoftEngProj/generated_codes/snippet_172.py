def lis(arr):
    ends = [0] * len(arr)
    longest = 0
    for i, val in enumerate(arr):
        prefix_lengths = [j for j in range(1, longest + 1) if arr[ends[j-1]] < val]
        length = max(prefix_lengths) if prefix_lengths else 0
        if length == longest or val < arr[ends[length]]:
            ends[length] = i
            longest = max(longest, length + 1)
    return longest