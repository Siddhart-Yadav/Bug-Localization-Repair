def get_factors(n):
    factors = []
    if n == 1:
        return []
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            factors.append(i)
    if not factors:
        factors.append(n)
    return factors