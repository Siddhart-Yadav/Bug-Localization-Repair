def kheapsort(arr, k):
    import heapq
    heap = arr[:k]
    heapq.heapify(heap)
    for x in arr[k:]:
        heapq.heappush(heap, x)
        yield heapq.heappop(heap)
    while heap:
        yield heapq.heappop(heap)